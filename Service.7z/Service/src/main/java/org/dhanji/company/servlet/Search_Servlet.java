package org.dhanji.company.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dhanji.company.database_connection.*;
/**
 * Servlet implementation class Search_Servlet
 */
public class Search_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	HashMap<String,String>hmap=new HashMap();
	String text=new String(request.getParameter("search").toLowerCase());
	Database_Connection obj=new Database_Connection();
	Statement stat=null;
	try
	{
	stat=obj.con.createStatement();
	ResultSet rset=stat.executeQuery("select name,path from binarydata");
	while(rset.next())
	{
	if(rset.getString("name").toString().toLowerCase().contains(text))
	hmap.put(rset.getString("name").toString(),rset.getString("path"));
	}
	obj.con.close();
	stat.close();
	
	if(hmap.size()>0)
	{
	request.setAttribute("values",hmap);
	request.getRequestDispatcher("Load_Content.jsp").forward(request,response);
	}	
	else
	request.getRequestDispatcher("index.jsp").forward(request,response);
	
	}catch(Exception e){}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
