package org.dhanji.company.Model;

public class City_temperature
{
String city,temp;

public synchronized String getCity() {
	return city;
}

public synchronized void setCity(String city) {
	this.city = city;
}

public synchronized String getTemp() {
	return temp;
}

public synchronized void setTemp(String temp) {
	this.temp = temp;
}

}
