package org.dhanji.company.servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class Servlet_Collection extends HttpServlet 
{
private static final long serialVersionUID = 1L;
public Servlet_Collection() 
{
super();
}
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
String selected=request.getParameter("content");
request.setAttribute("Selected_Value",selected);
request.getRequestDispatcher("Load_Content.jsp").forward(request,response);
}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
}

}
