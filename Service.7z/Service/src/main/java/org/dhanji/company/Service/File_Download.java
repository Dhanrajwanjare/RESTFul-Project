package org.dhanji.company.Service;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.StringTokenizer;
import javax.ws.rs.GET;
import javax.ws.rs.core.*;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;

import java.io.*;
@Path("/Download")
public class File_Download 
{
	@GET
	@Path("/download")
	//@Produces(MediaType.APPLICATION_OCTET_STREAM)
public Response test(@Context UriInfo ui)
{
String uri=new String(ui.getRequestUri().toString());
int indx1,indx2;
indx1=uri.indexOf("?");
indx2=uri.indexOf("=");
String content=null;
content=new String(uri.substring(indx1+1,indx2));
StringTokenizer stk=new StringTokenizer(content,"+");
StringBuffer bfr=new StringBuffer();
while(stk.hasMoreTokens())
bfr.append(stk.nextToken()+" ");	
content=new String(bfr);
System.out.println("content : " + content);
File file = new File("e:\\upload\\"+content);
ResponseBuilder responseBuilder = Response.ok((Object) file);
responseBuilder.header("Content-Disposition", "attachment; filename="+file.getName());
return responseBuilder.build();
}
}
	

