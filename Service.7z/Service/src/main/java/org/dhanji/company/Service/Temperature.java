package org.dhanji.company.Service;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import org.dhanji.company.Model.City_temperature;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.dhanji.company.database_connection.Database_Connection;

import java.util.List;
import java.util.ArrayList;
@Path("/City_Temperature")
public class Temperature
{
	Connection con;
	Statement stat;
	@GET
	@Path("/test")
	@Produces(MediaType.TEXT_PLAIN)
	public String test()
	{
	return("test");	
	}
	@GET
	@Produces(MediaType.TEXT_HTML)
	//public String getCityTemperature(@PathParam("ctyid")String cty)
	public String getCityTemperature(@Context UriInfo ui)
	{
	String response=null;
	String uri=new String(ui.getRequestUri().toString());
	int indx1,indx2;
	indx1=uri.indexOf("=");
	indx2=uri.indexOf("&");
	String content=null;
	content=new String(uri.substring(indx1+1,indx2));
	try
	{
	Database_Connection obj=new Database_Connection();
	con=obj.con;
	stat=con.createStatement();
	ResultSet rset=stat.executeQuery("select temp from temperature where city='" + content + "'   ");
	if(rset.next())
	response=new String("City  : " + content + "  " + "\n" + "Temperature : " + rset.getString(1));
	//System.out.println("response : " + response);
	con.close();
	stat.close();
	}catch(Exception e){System.out.println("Error : " + e.toString());}
	return(response);
	}

/*	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<City_temperature> getCityTemperature()
	{
		ArrayList<City_temperature>list=null;
		City_temperature object=null;
	try
	{
	Database_Connection obj=new Database_Connection();
	con=obj.con;
	stat=con.createStatement();
	list=new ArrayList();
	ResultSet rset=stat.executeQuery("select * from temperature");
	while(rset.next())
	{
		object=new City_temperature();
		object.setCity(rset.getString(1));
		object.setTemp(rset.getString(2));
		list.add(object);
	}
	con.close();
	stat.close();
	}catch(Exception e){System.out.println("Error : " + e.toString());}
	return(list);
	}*/
	
	
}
