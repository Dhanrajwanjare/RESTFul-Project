package org.dhanji.company.Model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.dhanji.company.database_connection.Database_Connection;
public class Load_Contents 
{
	String type;
	public HashMap<String,String>hmap;
	public Load_Contents(String type)
	{
	this.type=type;
	hmap=new HashMap();
	}
	public HashMap<String,String> fetchData()
	{
	Database_Connection obj=new Database_Connection();
	Connection connection=obj.con;
	Statement stat=null;
	try
	{
	stat=connection.createStatement();
	ResultSet rset=stat.executeQuery("select name,path from binarydata where type='" + type + "' ");
	while(rset.next())
		hmap.put(rset.getString("name"),rset.getString("path"));
	connection.close();
	stat.close();
	}catch(Exception e){}
	return(hmap);	
	}
}
