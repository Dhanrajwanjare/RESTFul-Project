package org.dhanji.company.database_connection;
import java.sql.*;

public class Database_Connection 
{
public  Connection con;
public Database_Connection()
{
	con=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:oci8:@localhost:1521:XE","scott","tiger");
	} catch (Exception e) {}
}
}
