package org.dhanji.company.Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;

import org.dhanji.company.database_connection.Database_Connection;


public class Load_Temperature {
	public HashSet<String>hset;
	public Load_Temperature()
	{
	hset=new HashSet();	
	}
	public HashSet<String> fetchData()
	{
	Database_Connection obj=new Database_Connection();
	Connection connection=obj.con;
	Statement stat=null;
	try
	{
	stat=connection.createStatement();
	ResultSet rset=stat.executeQuery("select city from temperature");
	while(rset.next())
		hset.add(rset.getString("city"));
	connection.close();
	stat.close();
	}catch(Exception e){}

	return(hset);	
	}

}
