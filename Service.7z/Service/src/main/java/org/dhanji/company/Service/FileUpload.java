package org.dhanji.company.Service;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ResponseCache;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import java.io.*;
import java.util.*;
import org.dhanji.company.database_connection.*;
import java.sql.*;
@Path("/fileUpload")
public class FileUpload 
{
	@Path("/upload")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String fileUpload(@FormDataParam("file") InputStream fileInputStream,@FormDataParam("file") FormDataContentDisposition fileMetaData)
	{
		String filename=new String(fileMetaData.getFileName());
		int i=filename.length()-1;
		while(filename.charAt(i--)!='.');
		String type=new String(filename.substring(i+2,filename.length()));
		Database_Connection obj=new Database_Connection();
		PreparedStatement statement =null;
		int status=0;
		String path=new String("e:\\upload\\"+filename);
		Write_To_File(fileInputStream,filename);
		try
		{
		statement= obj.con.prepareStatement("insert into binarydata values(?,?,?)");
        statement.setString(1,filename);
        statement.setString(2,type);
        statement.setString(3,path);
        status=statement.executeUpdate();
        obj.con.close();
		}catch(Exception e){return(e.toString());}
       if(status>0)
   	   return("File Uploaded");
   	   else
 	   return("File Not Uploaded");
 }
	public void Write_To_File(InputStream fileInputStream,String fileName) 
	{
		String UPLOAD_PATH = "e:/upload/";
	    try
	    {
	        int read = 0;
	        byte[] bytes = new byte[1024];
	 
	        OutputStream out = new FileOutputStream(new File(UPLOAD_PATH + fileName));
	        while ((read = fileInputStream.read(bytes)) != -1) 
	        {
	            out.write(bytes, 0, read);
	        }
	        out.flush();
	        out.close();
	    } catch (IOException e) 
	    {
	        throw new WebApplicationException("Error while uploading file. Please try again !!");
	    }
	
	}
		
		
}
